<?php 
    $fp = fopen("compteur.txt","r+");
?>